import { useScrollReveal } from './useScrollReveal';
import { bio, stats, education } from './data';
import { FiMapPin, FiBookOpen } from 'react-icons/fi';

export function About() {
  const [ref, isVisible] = useScrollReveal();

  return (
    <section id="about" className="py-20 md:py-28 bg-brand relative">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Section heading */}
        <div className="text-center mb-12 md:mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">About Me</h2>
          <p className="text-muted max-w-2xl mx-auto">Get to know more about my background and experience.</p>
        </div>
        
        {/* Content */}
        <div 
          ref={ref}
          className={`grid grid-cols-1 md:grid-cols-5 gap-12 transition-all duration-700 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}
        >
          {/* Left column */}
          <div className="md:col-span-2 flex flex-col items-center">
            <div className="relative w-60 h-72 md:w-64 md:h-80 mb-8 group mx-auto">
              <div className="absolute -inset-1.5 rounded-2xl bg-gradient-to-br from-accent via-cyan to-accent opacity-40 blur-md group-hover:opacity-65 transition-opacity duration-500"></div>
              <div className="relative w-full h-full rounded-2xl overflow-hidden border border-white/10 shadow-2xl">
                <img
                  src="/profile.jpg"
                  alt="Nihal Yadav"
                  className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-105"
                  style={{ objectPosition: 'center 15%' }}
                  loading="eager"
                />
              </div>
            </div>
            
            <div className="glass rounded-2xl p-6 w-full max-w-sm">
              <div className="flex items-center gap-2 text-white font-semibold mb-4 border-b border-white/5 pb-3">
                <FiBookOpen className="text-accent" />
                <h3>Education</h3>
              </div>
              <div>
                <p className="text-white font-medium">{education.school}</p>
                <p className="text-slate-300 text-sm mt-1">{education.degree}</p>
                <div className="flex justify-between items-center mt-3 text-xs text-muted">
                  <span>{education.period}</span>
                  <span className="font-mono bg-white/5 px-2 py-1 rounded">GPA: {education.gpa}</span>
                </div>
              </div>
            </div>
          </div>

          {/* Right column */}
          <div className="md:col-span-3 flex flex-col justify-center">
            <div className="mb-10 text-slate-300 space-y-4 leading-relaxed">
              {bio.map((paragraph, idx) => (
                <p key={idx}>{paragraph}</p>
              ))}
            </div>

            <div className="grid grid-cols-2 gap-4 md:gap-6">
              {stats.map((stat, idx) => (
                <div key={idx} className="glass rounded-xl p-4 md:p-6 transition-transform hover:-translate-y-1">
                  <div className="text-2xl md:text-3xl font-bold text-accent mb-2">{stat.value}</div>
                  <div className="text-sm text-muted">{stat.label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
