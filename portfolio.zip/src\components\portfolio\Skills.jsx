import { useScrollReveal } from './useScrollReveal';
import { useSpotlight } from './useInteractiveEffects';
import { skills } from './data';

function SkillCard({ category, index, isVisible }) {
  const spotlight = useSpotlight();

  const delayClasses = ["delay-0", "delay-100", "delay-200", "delay-300", "delay-500"];
  const delayClass = delayClasses[index % delayClasses.length];

  return (
    <div 
      ref={spotlight.ref}
      onMouseMove={spotlight.onMouseMove}
      onMouseLeave={spotlight.onMouseLeave}
      style={spotlight.style}
      className={`glass spotlight-card rounded-2xl p-6 transition-all duration-700 ${delayClass} ${
        isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
      }`}
    >
      <div className={`h-[3px] w-[40px] mb-4 rounded-full ${index % 2 === 0 ? 'bg-cyan' : 'bg-accent'}`}></div>
      <h3 className="text-lg font-semibold text-white mb-5">{category.name}</h3>
      <div className="flex flex-wrap gap-2 relative z-10">
        {category.items.map((item, itemIdx) => (
          <span 
            key={itemIdx}
            className="skill-badge bg-white/5 border border-white/10 rounded-lg px-3 py-1.5 text-sm text-slate-300 font-mono cursor-default hover:bg-white/10 transition-colors"
          >
            {item}
          </span>
        ))}
      </div>
    </div>
  );
}

export function Skills() {
  const [ref, isVisible] = useScrollReveal();

  return (
    <section id="skills" className="py-20 md:py-28 bg-brand-dark relative">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12 md:mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Technical Skills</h2>
          <p className="text-muted max-w-2xl mx-auto">Bridging machine learning concepts with robust backend engineering.</p>
        </div>

        <div 
          ref={ref} 
          className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6"
        >
          {skills.map((category, index) => (
            <SkillCard
              key={index}
              category={category}
              index={index}
              isVisible={isVisible}
            />
          ))}
        </div>
      </div>
    </section>
  );
}
