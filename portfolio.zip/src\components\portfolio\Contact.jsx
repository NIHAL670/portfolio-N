import { useState } from 'react';
import { useScrollReveal } from './useScrollReveal';
import { personalInfo } from './data';
import { FiMail, FiLinkedin, FiGithub, FiBox, FiSend, FiCheckCircle, FiAlertCircle } from 'react-icons/fi';

const socialLinks = [
  { key: 'linkedin', Icon: FiLinkedin, label: 'LinkedIn' },
  { key: 'github', Icon: FiGithub, label: 'GitHub' },
  { key: 'huggingface', Icon: FiBox, label: 'HuggingFace' },
];

export function Contact() {
  const [ref, isVisible] = useScrollReveal();
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: 'Freelance Project',
    message: ''
  });

  const [status, setStatus] = useState('IDLE'); // IDLE, SENDING, SUCCESS, ERROR
  const [errorMsg, setErrorMsg] = useState('');

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!formData.name || !formData.email || !formData.message) {
      setStatus('ERROR');
      setErrorMsg('Please fill in all required fields.');
      return;
    }

    setStatus('SENDING');

    try {
      const response = await fetch(`https://formsubmit.co/ajax/${personalInfo.email}`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json"
        },
        body: JSON.stringify({
          name: formData.name,
          email: formData.email,
          _subject: `[Portfolio] ${formData.subject} - ${formData.name}`,
          message: formData.message
        })
      });

      const result = await response.json();
      if (result.success === "true" || response.ok) {
        setStatus('SUCCESS');
        setFormData({ name: '', email: '', subject: 'Freelance Project', message: '' });
      } else {
        setStatus('ERROR');
        setErrorMsg('Failed to send message. Please try again.');
      }
    } catch {
      setStatus('ERROR');
      setErrorMsg('Failed to send message. Please check your network connection.');
    }
  };

  return (
    <section id="contact" className="py-20 md:py-28 bg-brand-dark relative">
      <div
        ref={ref}
        className={`max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 transition-all duration-700 ${
          isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'
        }`}
      >
        <div className="text-center mb-12 md:mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Let&apos;s Work Together</h2>
          <p className="text-muted max-w-2xl mx-auto">Have an opening, a freelance project, or just want to chat about ML pipelines?</p>
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-5 gap-12 items-start">
          {/* Info Side */}
          <div className="lg:col-span-2 space-y-8">
            <div>
              <h3 className="text-xl font-semibold text-white mb-4">Contact Info</h3>
              <p className="text-slate-300 text-sm leading-relaxed mb-6">
                {personalInfo.valueProposition}
              </p>
              
              <div className="space-y-4">
                <div className="flex items-center gap-3">
                  <div className="w-10 h-10 rounded-lg bg-accent/15 flex items-center justify-center text-accent">
                    <FiMail size={18} />
                  </div>
                  <div>
                    <div className="text-xs text-muted font-mono">EMAIL ME</div>
                    <a href={`mailto:${personalInfo.email}`} className="text-sm text-white hover:text-cyan transition-colors">
                      {personalInfo.email}
                    </a>
                  </div>
                </div>

                {personalInfo.phone && (
                  <div className="flex items-center gap-3">
                    <div className="w-10 h-10 rounded-lg bg-cyan/15 flex items-center justify-center text-cyan">
                      <span className="text-sm font-bold">#</span>
                    </div>
                    <div>
                      <div className="text-xs text-muted font-mono">CALL ME</div>
                      <span className="text-sm text-white font-mono">
                        {personalInfo.phone}
                      </span>
                    </div>
                  </div>
                )}
              </div>
            </div>

            <div className="pt-6 border-t border-white/5">
              <h4 className="text-sm font-semibold text-white mb-4">FIND ME ON</h4>
              <div className="flex items-center gap-4">
                {socialLinks.map(({ key, Icon, label }) => (
                  <a
                    key={key}
                    href={personalInfo.socials?.[key] || "#"}
                    target="_blank"
                    rel="noreferrer"
                    className="w-11 h-11 rounded-xl glass flex items-center justify-center text-slate-300 hover:text-white hover:border-white/20 transition-all cursor-pointer"
                    aria-label={label}
                  >
                    <Icon size={20} />
                  </a>
                ))}
              </div>
            </div>
          </div>

          {/* Form Side */}
          <div className="lg:col-span-3">
            <form onSubmit={handleSubmit} className="glass rounded-2xl p-6 md:p-8 space-y-6 border border-white/5 relative">
              <h3 className="text-lg font-semibold text-white mb-2">Send a Message</h3>
              
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6">
                <div>
                  <label htmlFor="name" className="block text-xs font-mono text-muted mb-2 uppercase">Full Name *</label>
                  <input
                    type="text"
                    id="name"
                    name="name"
                    value={formData.name}
                    onChange={handleChange}
                    required
                    className="w-full bg-brand-dark/50 border border-white/10 rounded-xl px-4 py-3 text-slate-200 text-sm focus:border-accent focus:ring-1 focus:ring-accent outline-none transition-all"
                    placeholder="Enter your name"
                  />
                </div>
                <div>
                  <label htmlFor="email" className="block text-xs font-mono text-muted mb-2 uppercase">Email Address *</label>
                  <input
                    type="email"
                    id="email"
                    name="email"
                    value={formData.email}
                    onChange={handleChange}
                    required
                    className="w-full bg-brand-dark/50 border border-white/10 rounded-xl px-4 py-3 text-slate-200 text-sm focus:border-accent focus:ring-1 focus:ring-accent outline-none transition-all"
                    placeholder="name@company.com"
                  />
                </div>
              </div>

              <div>
                <label htmlFor="subject" className="block text-xs font-mono text-muted mb-2 uppercase">Inquiry Type</label>
                <select
                  id="subject"
                  name="subject"
                  value={formData.subject}
                  onChange={handleChange}
                  className="w-full bg-brand-dark/50 border border-white/10 rounded-xl px-4 py-3 text-slate-200 text-sm focus:border-accent outline-none transition-all font-mono"
                >
                  <option value="Freelance Project">Freelance Project / Contract</option>
                  <option value="Full-time Job">Full-time Job Opportunity</option>
                  <option value="Technical Collaboration">Technical Collaboration</option>
                  <option value="Other">Other / Questions</option>
                </select>
              </div>

              <div>
                <label htmlFor="message" className="block text-xs font-mono text-muted mb-2 uppercase">Message *</label>
                <textarea
                  id="message"
                  name="message"
                  value={formData.message}
                  onChange={handleChange}
                  required
                  rows="4"
                  className="w-full bg-brand-dark/50 border border-white/10 rounded-xl px-4 py-3 text-slate-200 text-sm focus:border-accent focus:ring-1 focus:ring-accent outline-none transition-all"
                  placeholder="Tell me about your project or job opening..."
                />
              </div>

              <button
                type="submit"
                disabled={status === 'SENDING'}
                className="w-full bg-accent hover:bg-accent-hover disabled:bg-surface text-white py-3.5 px-6 rounded-xl font-semibold text-sm tracking-wider uppercase transition-colors flex items-center justify-center gap-2 cursor-pointer shadow-lg shadow-accent/15"
              >
                {status === 'SENDING' ? (
                  <>
                    <span className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></span>
                    Sending Message...
                  </>
                ) : (
                  <>
                    <FiSend /> Send Message
                  </>
                )}
              </button>

              {/* Status Feedbacks */}
              {status === 'SUCCESS' && (
                <div className="absolute inset-0 bg-brand/95 backdrop-blur-sm rounded-2xl flex flex-col items-center justify-center p-6 text-center animate-fade-in z-20">
                  <FiCheckCircle className="text-cyan mb-4" size={52} />
                  <h4 className="text-xl font-bold text-white mb-2">Message Sent!</h4>
                  <p className="text-slate-300 text-sm max-w-xs">
                    Thank you for reaching out. I will review your message and reply within 24 hours.
                  </p>
                  <button 
                    onClick={() => setStatus('IDLE')}
                    className="mt-6 text-xs text-accent hover:underline font-mono cursor-pointer"
                  >
                    Send another message
                  </button>
                </div>
              )}

              {status === 'ERROR' && (
                <div className="flex items-center gap-2 text-danger text-xs font-mono mt-2 animate-slide-up">
                  <FiAlertCircle size={16} />
                  <span>{errorMsg}</span>
                </div>
              )}
            </form>
          </div>
        </div>
      </div>
    </section>
  );
}
