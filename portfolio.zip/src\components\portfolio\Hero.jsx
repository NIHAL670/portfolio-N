import { useState, useEffect, useMemo } from 'react';
import { FiChevronDown } from 'react-icons/fi';
import { personalInfo } from './data';
import { useMagnetic, Scramble } from './useInteractiveEffects';

function Particles() {
  const particles = useMemo(() =>
    Array.from({ length: 25 }, (_, i) => ({
      id: i,
      left: `${Math.random() * 100}%`,
      delay: `${Math.random() * 8}s`,
      duration: `${8 + Math.random() * 12}s`,
      size: `${1 + Math.random() * 2}px`,
      opacity: 0.15 + Math.random() * 0.35,
    })), []
  );

  return (
    <div className="absolute inset-0 overflow-hidden pointer-events-none">
      {particles.map(p => (
        <div
          key={p.id}
          className="particle"
          style={{
            left: p.left,
            bottom: '-5%',
            width: p.size,
            height: p.size,
            animationDelay: p.delay,
            animationDuration: p.duration,
            opacity: p.opacity,
          }}
        />
      ))}
    </div>
  );
}

// Creative left-side ML training monitor telemetry panel
function MLTrainingWidget({ trigger }) {
  const [epoch, setEpoch] = useState(382);
  const [loss, setLoss] = useState(0.042);
  const [acc, setAcc] = useState(97.85);

  useEffect(() => {
    if (!trigger) return;
    const interval = setInterval(() => {
      setEpoch(prev => (prev < 500 ? prev + 1 : 380));
      setLoss(prev => Math.max(0.012, prev - (Math.random() * 0.0018)));
      setAcc(prev => Math.min(99.82, prev + (Math.random() * 0.045)));
    }, 1500);
    return () => clearInterval(interval);
  }, [trigger]);

  const bars = useMemo(() => 
    Array.from({ length: 12 }, () => 15 + Math.random() * 25), [epoch]
  );

  return (
    <div className={`hidden lg:flex flex-col absolute left-[2%] xl:left-[6%] top-[30%] w-60 glass p-4 rounded-2xl border border-white/5 select-none shadow-2xl shadow-accent/5 z-20 transition-all duration-1000 ${
      trigger ? 'opacity-100 translate-x-0' : 'opacity-0 -translate-x-12'
    }`} style={{ animation: 'float 6s ease-in-out infinite' }}>
      <div className="flex items-center justify-between mb-3 pb-2 border-b border-white/5">
        <div className="flex items-center gap-1.5">
          <span className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></span>
          <span className="text-[9px] font-mono text-muted uppercase tracking-wider">ML_TRAIN_MONITOR</span>
        </div>
        <span className="text-[9px] font-mono text-slate-400">EPOCH {epoch}/500</span>
      </div>
      <div className="space-y-2.5 font-mono text-xs text-slate-300">
        <div className="flex justify-between">
          <span className="text-muted text-[10px]">Loss Rate:</span>
          <span className="text-rose-400 font-semibold">{loss.toFixed(4)}</span>
        </div>
        <div className="flex justify-between">
          <span className="text-muted text-[10px]">Accuracy:</span>
          <span className="text-emerald-400 font-semibold">{acc.toFixed(2)}%</span>
        </div>
        <div className="pt-2">
          <div className="text-[9px] text-muted mb-1">CONVERGENCE CURVE</div>
          <div className="h-8 flex items-end gap-1.5">
            {bars.map((height, i) => (
              <div
                key={i}
                className="w-full bg-gradient-to-t from-accent/30 to-accent rounded-sm transition-all duration-500"
                style={{ height: `${height}px` }}
              />
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

// Creative right-side API status and network ping latency panel
function APIMonitorWidget({ trigger }) {
  const [requests, setRequests] = useState(14820);
  const [latency, setLatency] = useState(14);

  useEffect(() => {
    if (!trigger) return;
    const interval = setInterval(() => {
      setRequests(prev => prev + Math.floor(Math.random() * 4) + 1);
      setLatency(prev => Math.max(8, Math.min(26, prev + (Math.random() - 0.5) * 4)));
    }, 1200);
    return () => clearInterval(interval);
  }, [trigger]);

  return (
    <div className={`hidden lg:flex flex-col absolute right-[2%] xl:right-[6%] top-[34%] w-60 glass p-4 rounded-2xl border border-white/5 select-none shadow-2xl shadow-cyan/5 z-20 transition-all duration-1000 ${
      trigger ? 'opacity-100 translate-x-0' : 'opacity-0 translate-x-12'
    }`} style={{ animation: 'float 6s ease-in-out infinite', animationDelay: '1.5s' }}>
      <div className="flex items-center justify-between mb-3 pb-2 border-b border-white/5">
        <div className="flex items-center gap-1.5">
          <span className="w-2 h-2 rounded-full bg-cyan animate-pulse"></span>
          <span className="text-[9px] font-mono text-cyan uppercase tracking-wider">API_LATENCY_DAEMON</span>
        </div>
        <span className="text-[9px] font-mono text-slate-400">RTT</span>
      </div>
      <div className="space-y-2.5 font-mono text-xs text-slate-300">
        <div className="flex justify-between">
          <span className="text-muted text-[10px]">POST /predict:</span>
          <span className="text-cyan font-semibold">{latency.toFixed(0)} ms</span>
        </div>
        <div className="flex justify-between">
          <span className="text-muted text-[10px]">Total Calls:</span>
          <span className="text-white font-semibold">{requests.toLocaleString()}</span>
        </div>
        <div className="pt-2">
          <div className="text-[9px] text-muted mb-1">HEALTH INTEGRITY</div>
          <div className="flex flex-col gap-1">
            <div className="flex items-center justify-between text-[10px]">
              <span className="text-slate-400">Status 200</span>
              <span className="text-emerald-400 font-semibold">99.98%</span>
            </div>
            <div className="w-full bg-brand h-1.5 rounded-full overflow-hidden">
              <div className="h-full bg-cyan rounded-full" style={{ width: '99.98%' }} />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export function Hero() {
  const [roleIndex, setRoleIndex] = useState(0);
  const [charIndex, setCharIndex] = useState(0);
  const [isDeleting, setIsDeleting] = useState(false);
  const [animateHero, setAnimateHero] = useState(false);

  const currentRole = personalInfo.roles[roleIndex];
  const displayText = currentRole.substring(0, charIndex);

  // Magnetic button effects
  const btn1 = useMagnetic(0.2);
  const btn2 = useMagnetic(0.2);

  // Delay hero animations until intro is done
  useEffect(() => {
    const timer = setTimeout(() => setAnimateHero(true), 3600);
    return () => clearTimeout(timer);
  }, []);

  // Typing effect
  useEffect(() => {
    if (!animateHero) return;

    let timeout;
    if (!isDeleting && charIndex < currentRole.length) {
      timeout = setTimeout(() => setCharIndex(prev => prev + 1), 80);
    } else if (!isDeleting && charIndex === currentRole.length) {
      timeout = setTimeout(() => setIsDeleting(true), 2000);
    } else if (isDeleting && charIndex > 0) {
      timeout = setTimeout(() => setCharIndex(prev => prev - 1), 40);
    } else if (isDeleting && charIndex === 0) {
      setIsDeleting(false);
      setRoleIndex(prev => (prev + 1) % personalInfo.roles.length);
    }
    return () => clearTimeout(timeout);
  }, [charIndex, isDeleting, currentRole.length, roleIndex, animateHero]);

  const stagger = (n) =>
    `hero-stagger hero-stagger-${n} ${animateHero ? 'animate' : ''}`;

  return (
    <section id="hero" className="relative min-h-screen flex items-center justify-center overflow-hidden bg-brand">
      {/* Dot grid */}
      <div className="absolute inset-0 hero-grid opacity-15"></div>

      {/* Animated glow orbs */}
      <div className="absolute inset-0 flex items-center justify-center pointer-events-none">
        <div className="hero-glow-animated w-[800px] h-[800px] bg-accent/10 rounded-full blur-[120px]"></div>
      </div>
      <div className="absolute top-1/4 -right-32 pointer-events-none">
        <div className="hero-glow-animated w-[500px] h-[500px] bg-cyan/5 rounded-full blur-[100px]" style={{ animationDelay: '2.5s' }}></div>
      </div>

      {/* Floating particles */}
      <Particles />

      {/* Left side creative monitor */}
      <MLTrainingWidget trigger={animateHero} />

      {/* Right side creative monitor */}
      <APIMonitorWidget trigger={animateHero} />

      {/* Content */}
      <div className="relative z-10 max-w-6xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col items-center text-center">
        {/* Availability badge */}
        <div className={stagger(1)}>
          <div className="mb-6 inline-flex items-center space-x-2 px-4 py-2 rounded-full glass border border-white/10 hover:border-white/20 transition-colors">
            <span className="w-2.5 h-2.5 rounded-full bg-green-500 animate-pulse"></span>
            <span className="text-sm font-medium text-slate-300 font-mono">
              <Scramble text={personalInfo.availability} trigger={animateHero} delay={200} />
            </span>
          </div>
        </div>

        {/* Greeting */}
        <div className={stagger(2)}>
          <p className="text-muted text-lg mb-4 font-mono">
            <Scramble text="Hi, I'm" trigger={animateHero} delay={400} />
          </p>
        </div>

        {/* Name */}
        <div className={stagger(3)}>
          <h1 className="text-5xl md:text-7xl font-bold font-heading mb-6 tracking-tight gradient-text pb-2">
            <Scramble text={personalInfo.name} trigger={animateHero} delay={600} />
          </h1>
        </div>

        {/* Typing animation */}
        <div className={stagger(4)}>
          <div className="h-8 md:h-10 mb-8 flex items-center justify-center">
            <p className="font-mono text-xl md:text-2xl text-accent font-medium">
              {displayText}<span className="animate-blink">|</span>
            </p>
          </div>
        </div>

        {/* Tagline */}
        <div className={stagger(5)}>
          <p className="text-slate-300 text-lg max-w-2xl mx-auto mb-10 leading-relaxed">
            {personalInfo.tagline}
          </p>
        </div>

        {/* CTA Buttons */}
        <div className={stagger(6)}>
          <div className="flex flex-col sm:flex-row items-center justify-center gap-4 w-full sm:w-auto">
            <div 
              ref={btn1.ref} 
              onMouseMove={btn1.onMouseMove} 
              onMouseLeave={btn1.onMouseLeave} 
              style={btn1.style}
              className="w-full sm:w-auto"
            >
              <a
                href="#projects"
                className="block w-full sm:w-auto px-8 py-3 rounded-xl bg-accent hover:bg-accent-hover text-white font-medium transition-all duration-300 cursor-pointer shadow-lg shadow-accent/25 hover:shadow-accent/40"
              >
                View Projects
              </a>
            </div>
            <div 
              ref={btn2.ref} 
              onMouseMove={btn2.onMouseMove} 
              onMouseLeave={btn2.onMouseLeave} 
              style={btn2.style}
              className="w-full sm:w-auto"
            >
              <a
                href="#contact"
                className="block w-full sm:w-auto px-8 py-3 rounded-xl glass glass-hover text-white font-medium transition-all duration-300 cursor-pointer"
              >
                Get in Touch
              </a>
            </div>
          </div>
        </div>
      </div>

      {/* Scroll indicator */}
      <div className={`absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center justify-center ${stagger(6)}`}>
        <a href="#about" aria-label="Scroll down" className="text-muted hover:text-white transition-colors cursor-pointer scroll-indicator">
          <FiChevronDown size={32} />
        </a>
      </div>
    </section>
  );
}
