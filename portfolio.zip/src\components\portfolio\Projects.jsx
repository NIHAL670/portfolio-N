import { useState, useRef } from 'react';
import { FiExternalLink, FiGithub, FiX, FiAlertTriangle } from 'react-icons/fi';
import { useScrollReveal } from './useScrollReveal';
import { use3DTilt, useSpotlight } from './useInteractiveEffects';
import { projects } from './data';
import { CropPredictorPlayground, CryptoForecastPlayground } from './MlPlaygrounds';

function ProjectCard({ project, isSelected, onCardClick }) {
  // Combine 3D Tilt and Spotlight hooks
  const tilt = use3DTilt(8, 1.015);
  const spotlight = useSpotlight();

  // Handle combined mouse move
  const handleMouseMove = (e) => {
    tilt.onMouseMove(e);
    spotlight.onMouseMove(e);
  };

  // Handle combined mouse leave
  const handleMouseLeave = () => {
    tilt.onMouseLeave();
    spotlight.onMouseLeave();
  };

  // Combine refs (since both hooks require elements, we attach the container ref to tilt and let spotlight copy it or vice versa)
  const setRefs = (node) => {
    tilt.ref.current = node;
    spotlight.ref.current = node;
  };

  const combinedStyle = {
    ...tilt.style,
    ...spotlight.style
  };

  return (
    <div 
      ref={setRefs}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      onClick={onCardClick}
      style={combinedStyle}
      className={`glass spotlight-card rounded-2xl overflow-hidden cursor-pointer transition-all duration-300 ${
        isSelected ? 'border-accent/60 ring-2 ring-accent/25' : 'hover:border-white/10'
      }`}
    >
      <div className="h-32 bg-gradient-to-br from-accent/25 to-cyan/5 flex items-end p-6 relative">
        <h3 className="text-2xl font-bold text-white tracking-tight relative z-10">{project.title}</h3>
        {/* Subtle grid pattern inside card top */}
        <div className="absolute inset-0 hero-grid opacity-10 pointer-events-none"></div>
      </div>
      
      <div className="p-6 flex flex-col h-[calc(100%-8rem)] relative z-10">
        <p className="text-slate-300 text-sm line-clamp-3 mb-6 flex-grow">{project.summary}</p>
        
        <div className="flex flex-wrap gap-2 mb-6">
          {project.tech.slice(0, 4).map((tech, i) => (
            <span key={i} className="font-mono text-xs bg-white/5 border border-white/8 rounded px-2 py-1 text-muted">
              {tech}
            </span>
          ))}
          {project.tech.length > 4 && (
            <span className="font-mono text-xs bg-white/5 border border-white/8 rounded px-2 py-1 text-muted">
              +{project.tech.length - 4}
            </span>
          )}
        </div>
        
        <div className="text-accent text-sm font-medium hover:underline inline-flex items-center">
          {isSelected ? 'Close Case Study' : 'View Case Study'} &rarr;
        </div>
      </div>
    </div>
  );
}

export function Projects() {
  const [ref, isVisible] = useScrollReveal();
  const [selectedProjectId, setSelectedProjectId] = useState(null);

  const selectedProject = projects.find(p => p.id === selectedProjectId);

  return (
    <section id="projects" className="py-20 md:py-28 bg-brand relative">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div ref={ref} className={`transition-all duration-700 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}>
          <div className="text-center mb-12 md:mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Featured Projects</h2>
            <p className="text-muted max-w-2xl mx-auto">Explore some of my most impactful and complex technical implementations.</p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {projects.map((project) => {
              const isSelected = selectedProjectId === project.id;
              return (
                <ProjectCard 
                  key={project.id}
                  project={project}
                  isSelected={isSelected}
                  onCardClick={() => setSelectedProjectId(isSelected ? null : project.id)}
                />
              );
            })}
          </div>

          {/* CASE STUDY PANEL */}
          {selectedProject && (
            <div className="mt-8 transition-all duration-500 ease-in-out opacity-100 translate-y-0">
              <div className="glass rounded-2xl p-6 md:p-8 relative border border-accent/25">
                <button 
                  onClick={() => setSelectedProjectId(null)}
                  className="absolute top-6 right-6 p-2 rounded-full bg-white/5 hover:bg-white/10 text-muted hover:text-white transition-colors cursor-pointer"
                  aria-label="Close Case Study"
                >
                  <FiX size={20} />
                </button>

                <div className="pr-12 mb-8">
                  <div className="flex items-center gap-4 mb-2">
                    <h3 className="text-2xl md:text-3xl font-bold text-white">{selectedProject.title}</h3>
                    {selectedProject.type && (
                      <span className="px-3 py-1 rounded-full bg-accent/20 text-accent text-xs font-semibold tracking-wide uppercase border border-accent/30">
                        {selectedProject.type}
                      </span>
                    )}
                  </div>
                  <p className="text-lg text-cyan">{selectedProject.subtitle}</p>
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                  <div className="lg:col-span-2 space-y-8">
                    {/* The Problem */}
                    <div>
                      <h4 className="text-sm uppercase tracking-wider text-muted font-semibold mb-3">The Problem</h4>
                      <div className="flex gap-4">
                        <div className="w-1 rounded-full bg-danger flex-shrink-0"></div>
                        <p className="text-slate-300 leading-relaxed">{selectedProject.problem}</p>
                      </div>
                    </div>

                    {/* My Role & Solution */}
                    <div>
                      <h4 className="text-sm uppercase tracking-wider text-muted font-semibold mb-3">My Role & Solution</h4>
                      <div className="flex gap-4">
                        <div className="w-1 rounded-full bg-accent flex-shrink-0"></div>
                        <p className="text-slate-300 leading-relaxed">{selectedProject.role}</p>
                      </div>
                    </div>

                    {/* Key Technical Decision */}
                    {selectedProject.keyDecision && (
                      <div className="glass bg-surface/50 rounded-xl p-5 border border-white/5">
                        <div className="text-xs uppercase tracking-wider text-muted font-bold mb-2">The Tradeoff</div>
                        <h4 className="text-accent font-semibold text-lg mb-2">{selectedProject.keyDecision.title}</h4>
                        <p className="text-slate-300 text-sm leading-relaxed">{selectedProject.keyDecision.tradeoff}</p>
                      </div>
                    )}

                    {/* Interactive ML Simulator Playgrounds */}
                    {selectedProject.id === 'smart-agriculture' && <CropPredictorPlayground />}
                    {selectedProject.id === 'crypto-predictor' && <CryptoForecastPlayground />}
                  </div>

                  <div className="space-y-8">
                    {/* Tech Stack */}
                    <div>
                      <h4 className="text-sm uppercase tracking-wider text-muted font-semibold mb-3">Tech Stack</h4>
                      <div className="flex flex-wrap gap-2">
                        {selectedProject.tech.map((tech, i) => (
                          <span key={i} className="font-mono text-sm bg-white/5 border border-white/8 rounded px-3 py-1.5 text-slate-300">
                            {tech}
                          </span>
                        ))}
                      </div>
                    </div>

                    {/* Metrics */}
                    {selectedProject.metrics && (
                      <div>
                        <h4 className="text-sm uppercase tracking-wider text-muted font-semibold mb-3">Impact & Metrics</h4>
                        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-2 gap-4">
                          {selectedProject.metrics.map((metric, i) => (
                            <div key={i} className={`glass rounded-xl p-4 border border-white/5 ${metric.flag ? 'metric-flag bg-warning/5 border-warning/20' : ''}`}>
                              <div className="flex items-center gap-2 mb-1">
                                {metric.flag && <FiAlertTriangle className="text-warning flex-shrink-0" size={16} />}
                                <div className={`text-2xl font-bold ${metric.flag ? 'text-warning' : 'text-accent'}`}>
                                  {metric.value}
                                </div>
                              </div>
                              <div className="text-xs text-muted font-medium">{metric.label}</div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}

                    {/* Links */}
                    <div className="flex flex-col gap-3 pt-4 border-t border-white/10">
                      {selectedProject.liveUrl && (
                        <a 
                          href={selectedProject.liveUrl} 
                          target="_blank" 
                          rel="noreferrer"
                          className="flex items-center justify-center gap-2 bg-accent hover:bg-accent/90 text-white py-3 px-6 rounded-xl font-medium transition-colors cursor-pointer"
                        >
                          <FiExternalLink /> Live Demo
                        </a>
                      )}
                      {selectedProject.githubUrl && (
                        <a 
                          href={selectedProject.githubUrl} 
                          target="_blank" 
                          rel="noreferrer"
                          className="flex items-center justify-center gap-2 glass border border-accent/30 hover:bg-white/5 text-accent py-3 px-6 rounded-xl font-medium transition-colors cursor-pointer"
                        >
                          <FiGithub /> Source Code
                        </a>
                      )}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </section>
  );
}
