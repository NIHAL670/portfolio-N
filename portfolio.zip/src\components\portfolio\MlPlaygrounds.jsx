import { useState, useEffect, useRef } from "react";

// 1. CROP PREDICTOR SIMULATOR
export function CropPredictorPlayground() {
  const [inputs, setInputs] = useState({
    N: 50,
    P: 50,
    K: 50,
    pH: 6.5,
    temp: 28,
    rain: 150,
  });

  const [predictions, setPredictions] = useState([]);

  // Mock ML calibrated probability classifier in JS
  useEffect(() => {
    const calculatePredictions = () => {
      const { N, P, K, pH, temp, rain } = inputs;
      const scores = {
        Rice: 0,
        Maize: 0,
        Cotton: 0,
        Banana: 0,
        Tomato: 0,
        Potato: 0,
        Wheat: 0,
      };

      // Rules mapping soil & environmental bounds to crops
      if (rain > 180 && temp > 24 && N > 40) scores.Rice += 8;
      if (temp > 18 && temp < 30 && rain > 60 && rain < 120 && P > 45) scores.Maize += 7;
      if (pH > 5.5 && pH < 7.5 && N > 50 && K > 40 && rain < 100) scores.Cotton += 6;
      if (temp > 25 && K > 80 && rain > 150) scores.Banana += 9;
      if (pH > 6.0 && pH < 6.8 && P > 60 && temp > 20) scores.Tomato += 5;
      if (temp < 22 && rain > 80 && K > 70) scores.Potato += 7;
      if (temp > 10 && temp < 24 && rain < 90 && pH > 6.2) scores.Wheat += 6;

      // Add small NPK affinity
      scores.Rice += (N * 0.1) + (rain * 0.05);
      scores.Maize += (P * 0.12) + (temp * 0.1);
      scores.Cotton += (N * 0.08) + (K * 0.08);
      scores.Banana += (K * 0.15) + (rain * 0.04);
      scores.Tomato += (P * 0.1) + (pH * 0.5);
      scores.Potato += (K * 0.12) + (100 / temp);
      scores.Wheat += (N * 0.06) + (P * 0.06);

      // Normalize to percentages
      const sum = Object.values(scores).reduce((a, b) => a + b, 0) || 1;
      const results = Object.keys(scores).map(name => ({
        name,
        confidence: Math.round((scores[name] / sum) * 100),
      }));

      // Sort by confidence
      results.sort((a, b) => b.confidence - a.confidence);
      setPredictions(results.slice(0, 3)); // Top 3
    };

    calculatePredictions();
  }, [inputs]);

  const handleSliderChange = (key, value) => {
    setInputs(prev => ({ ...prev, [key]: value }));
  };

  return (
    <div className="glass bg-surface-light/40 border border-white/5 rounded-2xl p-5 md:p-6 mt-6">
      <div className="flex items-center justify-between mb-4 pb-2 border-b border-white/5">
        <h4 className="text-cyan font-semibold tracking-wide text-sm font-mono uppercase">Interactive ML Playground — Crop Recommender</h4>
        <span className="text-[10px] bg-cyan/15 text-cyan border border-cyan/20 px-2 py-0.5 rounded font-mono">Calibrated Softmax</span>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6 items-center">
        {/* Sliders */}
        <div className="space-y-4">
          <div>
            <div className="flex justify-between text-xs text-slate-300 font-mono mb-1">
              <span>Nitrogen (N): <span className="text-accent font-bold">{inputs.N} kg/ha</span></span>
              <span>Phosphorus (P): <span className="text-cyan font-bold">{inputs.P} kg/ha</span></span>
            </div>
            <div className="flex gap-2">
              <input type="range" min="10" max="140" value={inputs.N} onChange={e => handleSliderChange('N', parseInt(e.target.value))} className="w-full accent-accent h-1 bg-brand rounded-lg cursor-pointer" />
              <input type="range" min="10" max="140" value={inputs.P} onChange={e => handleSliderChange('P', parseInt(e.target.value))} className="w-full accent-cyan h-1 bg-brand rounded-lg cursor-pointer" />
            </div>
          </div>

          <div>
            <div className="flex justify-between text-xs text-slate-300 font-mono mb-1">
              <span>Potassium (K): <span className="text-accent font-bold">{inputs.K} kg/ha</span></span>
              <span>Soil pH: <span className="text-cyan font-bold">{inputs.pH}</span></span>
            </div>
            <div className="flex gap-2">
              <input type="range" min="10" max="140" value={inputs.K} onChange={e => handleSliderChange('K', parseInt(e.target.value))} className="w-full accent-accent h-1 bg-brand rounded-lg cursor-pointer" />
              <input type="range" min="4.0" max="9.0" step="0.1" value={inputs.pH} onChange={e => handleSliderChange('pH', parseFloat(e.target.value))} className="w-full accent-cyan h-1 bg-brand rounded-lg cursor-pointer" />
            </div>
          </div>

          <div>
            <div className="flex justify-between text-xs text-slate-300 font-mono mb-1">
              <span>Temperature: <span className="text-accent font-bold">{inputs.temp} °C</span></span>
              <span>Rainfall: <span className="text-cyan font-bold">{inputs.rain} mm</span></span>
            </div>
            <div className="flex gap-2">
              <input type="range" min="5" max="45" value={inputs.temp} onChange={e => handleSliderChange('temp', parseInt(e.target.value))} className="w-full accent-accent h-1 bg-brand rounded-lg cursor-pointer" />
              <input type="range" min="20" max="300" value={inputs.rain} onChange={e => handleSliderChange('rain', parseInt(e.target.value))} className="w-full accent-cyan h-1 bg-brand rounded-lg cursor-pointer" />
            </div>
          </div>
        </div>

        {/* Prediction Results */}
        <div className="glass bg-brand-dark/40 border border-white/5 rounded-xl p-4 flex flex-col justify-center h-full">
          <div className="text-xs text-muted mb-3 font-mono uppercase tracking-wider">Top Recommended Crops:</div>
          <div className="space-y-3">
            {predictions.map((p, idx) => (
              <div key={idx}>
                <div className="flex justify-between text-xs font-mono mb-1">
                  <span className="text-white font-medium">{idx + 1}. {p.name}</span>
                  <span className={idx === 0 ? "text-cyan font-bold" : "text-muted"}>{p.confidence}%</span>
                </div>
                <div className="w-full bg-brand h-1.5 rounded-full overflow-hidden">
                  <div 
                    className={`h-full transition-all duration-300 ${idx === 0 ? 'bg-cyan' : idx === 1 ? 'bg-accent' : 'bg-surface'}`} 
                    style={{ width: `${p.confidence}%` }}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

// 2. CRYPTO FORECAST SIMULATOR
export function CryptoForecastPlayground() {
  const [coin, setCoin] = useState("BTC");
  const [horizon, setHorizon] = useState(14);
  const [volatility, setVolatility] = useState(1.5);
  const [loading, setLoading] = useState(false);
  const canvasRef = useRef(null);

  const simulateForecast = () => {
    setLoading(true);
    setTimeout(() => {
      setLoading(false);
      drawForecast();
    }, 800);
  };

  const drawForecast = () => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    const w = canvas.width;
    const h = canvas.height;
    ctx.clearRect(0, 0, w, h);

    // Grid lines
    ctx.strokeStyle = "rgba(255, 255, 255, 0.03)";
    ctx.lineWidth = 1;
    for (let i = 0; i < w; i += 40) {
      ctx.beginPath();
      ctx.moveTo(i, 0);
      ctx.lineTo(i, h);
      ctx.stroke();
    }
    for (let i = 0; i < h; i += 30) {
      ctx.beginPath();
      ctx.moveTo(0, i);
      ctx.lineTo(w, i);
      ctx.stroke();
    }

    // Parameters based on selections
    const basePrice = coin === "BTC" ? 64000 : coin === "ETH" ? 3400 : 140;
    const pointsCount = 40;
    const forecastStartIdx = 25;
    const prices = [];

    // Historical generation (semi-random walk)
    let current = basePrice;
    for (let i = 0; i < pointsCount; i++) {
      if (i < forecastStartIdx) {
        current += (Math.random() - 0.48) * current * 0.02 * volatility;
        prices.push({ x: i, y: current, type: 'history' });
      } else {
        // Forecast generation
        const trend = coin === "BTC" ? 0.003 : coin === "ETH" ? 0.001 : -0.002;
        current += (Math.random() - 0.5 + trend) * current * 0.035 * volatility;
        
        // Calculate confidence limits
        const devSteps = i - forecastStartIdx + 1;
        const width = basePrice * 0.015 * devSteps * volatility;
        prices.push({
          x: i,
          y: current,
          type: 'forecast',
          upper: current + width,
          lower: current - width
        });
      }
    }

    const minPrice = Math.min(...prices.map(p => p.lower || p.y)) * 0.95;
    const maxPrice = Math.max(...prices.map(p => p.upper || p.y)) * 1.05;

    const scaleX = (val) => (val / (pointsCount - 1)) * (w - 20) + 10;
    const scaleY = (val) => h - 10 - ((val - minPrice) / (maxPrice - minPrice)) * (h - 20);

    // Draw confidence intervals
    ctx.fillStyle = "rgba(108, 99, 255, 0.05)";
    ctx.beginPath();
    ctx.moveTo(scaleX(forecastStartIdx), scaleY(prices[forecastStartIdx].y));
    for (let i = forecastStartIdx; i < pointsCount; i++) {
      ctx.lineTo(scaleX(i), scaleY(prices[i].upper));
    }
    for (let i = pointsCount - 1; i >= forecastStartIdx; i--) {
      ctx.lineTo(scaleX(i), scaleY(prices[i].lower));
    }
    ctx.closePath();
    ctx.fill();

    // Draw historical line
    ctx.strokeStyle = "#22d3ee";
    ctx.lineWidth = 2.5;
    ctx.beginPath();
    ctx.moveTo(scaleX(0), scaleY(prices[0].y));
    for (let i = 1; i < forecastStartIdx; i++) {
      ctx.lineTo(scaleX(i), scaleY(prices[i].y));
    }
    ctx.stroke();

    // Draw forecast line (dotted)
    ctx.strokeStyle = "#6c63ff";
    ctx.setLineDash([4, 4]);
    ctx.beginPath();
    ctx.moveTo(scaleX(forecastStartIdx - 1), scaleY(prices[forecastStartIdx - 1].y));
    for (let i = forecastStartIdx; i < pointsCount; i++) {
      ctx.lineTo(scaleX(i), scaleY(prices[i].y));
    }
    ctx.stroke();
    ctx.setLineDash([]); // reset

    // Draw vertical divider
    ctx.strokeStyle = "rgba(255, 255, 255, 0.2)";
    ctx.beginPath();
    ctx.moveTo(scaleX(forecastStartIdx - 1), 0);
    ctx.lineTo(scaleX(forecastStartIdx - 1), h);
    ctx.stroke();

    // Labels
    ctx.fillStyle = "#94a3b8";
    ctx.font = "10px JetBrains Mono";
    ctx.fillText("HISTORICAL", scaleX(2), 20);
    ctx.fillStyle = "#6c63ff";
    ctx.fillText("LSTM FORECAST", scaleX(forecastStartIdx + 1), 20);
  };

  useEffect(() => {
    drawForecast();
  }, [coin, horizon, volatility]);

  return (
    <div className="glass bg-surface-light/40 border border-white/5 rounded-2xl p-5 md:p-6 mt-6">
      <div className="flex items-center justify-between mb-4 pb-2 border-b border-white/5">
        <h4 className="text-cyan font-semibold tracking-wide text-sm font-mono uppercase">Interactive ML Playground — LSTM Time Series</h4>
        <span className="text-[10px] bg-accent/15 text-accent border border-accent/20 px-2 py-0.5 rounded font-mono">TensorFlow Model</span>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-center">
        <div className="space-y-4">
          <div>
            <label className="block text-xs font-mono text-slate-300 mb-1">Asset Target:</label>
            <select value={coin} onChange={e => setCoin(e.target.value)} className="w-full bg-brand text-slate-200 border border-white/10 rounded-lg px-3 py-2 text-sm font-mono">
              <option value="BTC">BTC / USD</option>
              <option value="ETH">ETH / USD</option>
              <option value="SOL">SOL / USD</option>
            </select>
          </div>
          <div>
            <label className="block text-xs font-mono text-slate-300 mb-1">Horizon Forecast:</label>
            <select value={horizon} onChange={e => setHorizon(parseInt(e.target.value))} className="w-full bg-brand text-slate-200 border border-white/10 rounded-lg px-3 py-2 text-sm font-mono">
              <option value="7">7 Days Ahead</option>
              <option value="14">14 Days Ahead</option>
              <option value="30">30 Days Ahead</option>
            </select>
          </div>
          <div>
            <div className="flex justify-between text-xs font-mono text-slate-300 mb-1">
              <span>Volatility:</span>
              <span className="text-cyan font-bold">{volatility}x</span>
            </div>
            <input type="range" min="0.5" max="3.0" step="0.1" value={volatility} onChange={e => setVolatility(parseFloat(e.target.value))} className="w-full accent-cyan h-1 bg-brand rounded-lg cursor-pointer" />
          </div>
          <button 
            onClick={simulateForecast}
            disabled={loading}
            className="w-full bg-accent hover:bg-accent-hover disabled:bg-surface text-white py-2 px-4 rounded-lg text-xs font-semibold tracking-wider uppercase transition-colors cursor-pointer"
          >
            {loading ? "RUNNING MODEL..." : "COMPUTE FORECAST"}
          </button>
        </div>

        <div className="md:col-span-2">
          <div className="relative border border-white/5 rounded-xl overflow-hidden bg-brand-dark/50">
            <canvas ref={canvasRef} width="360" height="180" className="w-full block" />
            {loading && (
              <div className="absolute inset-0 bg-brand-dark/70 flex items-center justify-center">
                <span className="text-xs font-mono text-cyan animate-pulse">Running forward pass...</span>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
