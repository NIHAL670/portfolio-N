export function Badge({ children, className = '' }) {
  return (
    <span className={`inline-block px-3 py-1 text-xs font-mono font-medium rounded-full bg-accent/15 text-accent border border-accent/20 ${className}`}>
      {children}
    </span>
  );
}
