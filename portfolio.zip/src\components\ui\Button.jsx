export function Button({ children, variant = 'primary', className = '', ...props }) {
  const base = 'inline-flex items-center justify-center gap-2 font-body font-medium rounded-full px-6 py-3 transition-all duration-300 cursor-pointer text-sm md:text-base';
  const variants = {
    primary: 'bg-accent text-white hover:bg-accent-hover shadow-lg shadow-accent/25 hover:shadow-accent/40',
    secondary: 'border-2 border-accent text-accent hover:bg-accent hover:text-white',
    outline: 'border-2 border-white/20 text-white hover:border-accent hover:text-accent',
    danger: 'bg-danger text-white hover:bg-red-600',
    ghost: 'text-muted hover:text-white hover:bg-white/5',
  };

  return (
    <button className={`${base} ${variants[variant] || variants.primary} ${className}`} {...props}>
      {children}
    </button>
  );
}
