import { useScrollReveal } from './useScrollReveal';
import { experience, education } from './data';
import { FiBookOpen } from 'react-icons/fi';

export function Experience() {
  const [ref, isVisible] = useScrollReveal();

  return (
    <section id="experience" className="py-20 md:py-28 bg-brand-dark relative">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-16">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Experience</h2>
          <p className="text-muted max-w-2xl mx-auto">My professional journey and academic background.</p>
        </div>

        <div ref={ref} className="relative">
          {/* Vertical timeline line */}
          <div className="hidden md:block absolute left-8 top-4 bottom-4 w-px bg-white/10"></div>

          <div className="space-y-12">
            {experience.map((job, index) => {
              const delayClasses = ["delay-0", "delay-100", "delay-200", "delay-300"];
              const delayClass = delayClasses[index % delayClasses.length];

              return (
                <div
                  key={index}
                  className={`relative flex flex-col md:flex-row gap-8 transition-all duration-700 ${delayClass} ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`}
                >
                {/* Timeline dot */}
                <div className="hidden md:flex flex-col items-center mt-6">
                  <div className="w-4 h-4 rounded-full bg-accent border-4 border-brand-dark z-10 shadow-[0_0_0_4px_rgba(108,99,255,0.2)]"></div>
                </div>

                {/* Card */}
                <div className="glass rounded-2xl p-6 md:p-8 flex-1 border border-white/5 hover:border-white/10 transition-colors">
                  <div className="flex flex-wrap justify-between items-start gap-4 mb-6">
                    <div>
                      <h3 className="text-xl font-semibold text-white mb-1">{job.title}</h3>
                      <div className="text-accent font-medium">{job.company}</div>
                    </div>

                    <div className="flex flex-col items-end gap-2">
                      <span className="text-muted text-sm font-mono">{job.period}</span>
                      {job.type && (
                        <span className={`rounded-full px-3 py-1 text-xs font-semibold ${
                          job.type.toLowerCase() === 'remote' ? 'bg-cyan/10 text-cyan' :
                          job.type.toLowerCase() === 'leadership' ? 'bg-accent/10 text-accent' :
                          'bg-white/10 text-white'
                        }`}>
                          {job.type}
                        </span>
                      )}
                    </div>
                  </div>

                  <ul className="space-y-3">
                    {job.highlights.map((highlight, i) => (
                      <li key={i} className="flex items-start gap-3 text-slate-300 text-sm leading-relaxed">
                        <span className="mt-1.5 w-1.5 h-1.5 rounded-full bg-accent/60 flex-shrink-0"></span>
                        <span>{highlight}</span>
                      </li>
                    ))}
                  </ul>
                </div>
                </div>
              );
            })}
          </div>

          {/* Education Card */}
          <div className={`mt-16 md:ml-16 transition-all duration-700 ${isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-8'}`} style={{ transitionDelay: '300ms' }}>
            <div className="glass rounded-2xl p-6 md:p-8 border border-white/5 flex flex-col md:flex-row items-center md:items-start gap-6">
              <div className="w-16 h-16 rounded-2xl bg-accent/10 flex items-center justify-center flex-shrink-0">
                <FiBookOpen size={28} className="text-accent" />
              </div>
              <div className="flex-1 text-center md:text-left">
                <div className="text-accent text-sm font-semibold uppercase tracking-wider mb-2">Education</div>
                <h3 className="text-xl font-semibold text-white mb-1">{education.school}</h3>
                <div className="text-slate-300 mb-2">{education.degree}</div>
                <div className="flex flex-wrap items-center justify-center md:justify-start gap-4 text-sm font-mono text-muted">
                  <span>{education.period}</span>
                  {education.gpa && (
                    <>
                      <span className="w-1 h-1 rounded-full bg-white/20"></span>
                      <span>GPA: {education.gpa}</span>
                    </>
                  )}
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
